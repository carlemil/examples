package com.sonymobile.sonyselect.bi;

public class TrackableScreens {
    public final static String LICENSE = "license";
    public final static String LAUNCH = "launch";
    public final static String DETAIL = "detail";
    public final static String DISCLAIMER_ACCEPTED = "disclaimer/accepted";
    public final static String DISCLAIMER_DECLINED = "disclaimer/declined";
}
