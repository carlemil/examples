package com.sonymobile.sonyselect.bi;

public class TrackableEvents {
    final static String VIEW = "view";
    final static String SHARE = "share";
    final static String DETAIL = "detail";
    final static String GET = "get";
    final static String INSTALL = "install";
}

