package com.sonymobile.sonyselect.listener;

public interface NextPageListener {

    public void getNextPage();

}
