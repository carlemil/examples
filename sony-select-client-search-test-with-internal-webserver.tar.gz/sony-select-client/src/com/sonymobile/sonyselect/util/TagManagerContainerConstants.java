package com.sonymobile.sonyselect.util;

public class TagManagerContainerConstants {

    public static final String SEARCH_ENABLED = "search_enabled";
    public static final String SEARCH_ROOT_URL = "search_root_url";
    public static final String SEARCH_API_KEY = "search_api_key";

    public static final String SEARCH_MIN_SUGGESTION_LENGTH = "search_min_suggestions_length";
}
