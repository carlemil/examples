package com.sonymobile.sonyselect.adapter;

public interface OnListClickListener {
    public void onItemClick(long listId, long itemId, int itemPosition, int numberOfItems);
}
