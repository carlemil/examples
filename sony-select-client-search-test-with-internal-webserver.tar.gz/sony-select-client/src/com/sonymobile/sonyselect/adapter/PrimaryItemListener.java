package com.sonymobile.sonyselect.adapter;

public interface PrimaryItemListener {

    void newPrimaryItemSet();

}
