package com.sonymobile.sonyselect.adapter;

import android.view.View;
import android.widget.TextView;

public interface ItemViewHolder {
    public TextView getTitle();
    public View getColor();
}
