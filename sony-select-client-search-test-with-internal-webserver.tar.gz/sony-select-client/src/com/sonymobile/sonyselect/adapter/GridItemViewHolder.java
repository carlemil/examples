package com.sonymobile.sonyselect.adapter;

import android.view.View;
import android.widget.TextView;

import com.sonymobile.sonyselect.components.RelativeHeightImageView;

public class GridItemViewHolder extends AbstractItemViewHolder {

    public GridItemViewHolder(RelativeHeightImageView image, TextView title, View color) {
        super(image, title, color);
    }
}
