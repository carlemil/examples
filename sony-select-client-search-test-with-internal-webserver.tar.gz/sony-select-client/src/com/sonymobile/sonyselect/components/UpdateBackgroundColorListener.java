package com.sonymobile.sonyselect.components;

public interface UpdateBackgroundColorListener {

    public void updateBackgroundColor();

}
