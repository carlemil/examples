package com.sonymobile.sonyselect.fragment;

public interface OnErrorDialogEventListener {
    public void onErrorDialogClose();
}
