#!/bin/bash
~/sony_android_sdk/14.2.A.0.53/tools/android update project -p .
ant jar
